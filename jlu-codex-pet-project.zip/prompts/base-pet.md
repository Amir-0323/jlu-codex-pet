Create one clean full-body reference sprite for ChatGPT pet Jilin Blue.

Pet identity: Preserve supplied blue rounded mascot, pale belly with Jilin University emblem, large pale green eyes and black pupils, small smiling mouth, attached arms and broad three-toed feet. Smooth 3D material. Reference image provided. Keep emblem orientation correct; do not mirror text..
Style: Pet-safe sprite: compact full-body mascot, readable in a 192x208 cell, clear silhouette, simple face, stable palette/materials, and crisp edges for chroma-key extraction. Style `3d-toy`: Stylized 3D toy mascot with smooth rounded forms, simple materials, clear silhouette, and no photoreal complexity.


Place a single centered pose on a perfectly flat pure magenta #FF00FF chroma-key background. Keep the full pet visible, compact, readable at 192x208, and easy to animate. Preserve approved reference identity cues. No scenery, text, borders, checkerboard transparency, shadows, glows, detached effects, or extra props. Keep #FF00FF and close colors out of the pet, props, highlights, and effects.
