Create ChatGPT pet row `waiting` for `jilin-blue`: exactly 6 full-body frames in one horizontal strip on flat pure magenta #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Preserve supplied blue rounded mascot, pale belly with Jilin University emblem, large pale green eyes and black pupils, small smiling mouth, attached arms and broad three-toed feet. Smooth 3D material. Reference image provided. Keep emblem orientation correct; do not mirror text.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Needs-input loop: expectant asking pose for approval, help, or user input.

State requirements:
- Show that ChatGPT needs approval, help, or user input through an expectant asking pose.
- Keep the motion patient and readable, without turning it into ordinary idle or review.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.
