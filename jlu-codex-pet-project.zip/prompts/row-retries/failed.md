Create ChatGPT pet row `failed` for `jilin-blue`: exactly 8 full-body frames in one horizontal strip on flat pure magenta #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Preserve supplied blue rounded mascot, pale belly with Jilin University emblem, large pale green eyes and black pupils, small smiling mouth, attached arms and broad three-toed feet. Smooth 3D material. Reference image provided. Keep emblem orientation correct; do not mirror text.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Blocked/failed loop: slumped or deflated reaction with sad or closed eyes.

State requirements:
- Show failure through slumped pose, drooping ears/limbs, closed or sad eyes, and lower body position.
- Tears, small smoke puffs, or tiny stars are allowed only if attached to or overlapping the pet silhouette and kept inside the same frame slot.
- Do not draw red X marks, floating symbols, detached stars, separated smoke clouds, falling tear drops, dust, or other loose effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.
